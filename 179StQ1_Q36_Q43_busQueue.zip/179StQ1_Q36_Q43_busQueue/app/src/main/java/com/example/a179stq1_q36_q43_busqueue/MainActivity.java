package com.example.a179stq1_q36_q43_busqueue;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;


public class MainActivity extends AppCompatActivity {

    private int Q43StopCount = 0;
    private String Q43PrettyMiles = null;

    private int Q36StopCount = 0;
    private String Q36PrettyMiles = null;


    private int Q1StopCount = 0;
    private String Q1PrettyMiles = null;


    RelativeLayout Q43Layout;
    RelativeLayout Q36Layout;
    RelativeLayout Q1Layout;


    TextView Q43Miles;
    TextView Q36Miles;
    TextView Q1Miles;

    TextView Q43Stops;
    TextView Q36Stops;
    TextView Q1Stops;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Q43Layout = findViewById(R.id.Q43Layout);
        Q36Layout = findViewById(R.id.Q36Layout);
        Q1Layout = findViewById(R.id.Q1Layout);

         Q43Miles = findViewById(R.id.Q43miles);
        Q36Miles = findViewById(R.id.Q36miles);
        Q1Miles = findViewById(R.id.Q1miles);

         Q43Stops = findViewById(R.id.Q43Stops);
         Q36Stops = findViewById(R.id.Q36Stops);
         Q1Stops = findViewById(R.id.Q1Stops);

         Button btn1 = findViewById(R.id.button);


         btn1.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 launch();
             }
         });


        launch();




    }


    private void launch(){
        getQ1();
        getQ36();
        getQ43();








    }


    private void getQ43(){

// ...

// Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="http://bustime.mta.info/api/siri/stop-monitoring.json?key=88059407-c3f9-4fb6-802c-c243ebe53cbb&OperatorRef=MTA&MonitoringRef=502044&LineRef=MTA NYCT_Q43";

// Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                      //  textView.setText("Response is: "+ response);
                        try {
                            JSONObject x = new JSONObject(response);

                            JSONObject nearestBus = x.getJSONObject("Siri").getJSONObject("ServiceDelivery").getJSONArray("StopMonitoringDelivery").getJSONObject(0).getJSONArray("MonitoredStopVisit").getJSONObject(0).getJSONObject("MonitoredVehicleJourney").getJSONObject("MonitoredCall").getJSONObject("Extensions").getJSONObject("Distances");

                            Q43StopCount = Integer.parseInt(nearestBus.getString("StopsFromCall"));

                            Q43PrettyMiles = nearestBus.getString("PresentableDistance");

                            Q43Miles.setText(Q43PrettyMiles);
                            Q43Stops.setText("Stops Away: " + Q43StopCount);


                        } catch (JSONException e) {
                            e.printStackTrace();
                            Q43StopCount = 0;
                            Q43PrettyMiles = "NO BUSES EN-ROUTE";
                            Q43Miles.setText(Q43PrettyMiles);
                            Q43Stops.setText("Stops Away: " + Q43StopCount);
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Q43StopCount = 0;
                Q43PrettyMiles = "API FAILED";
                Q43Miles.setText(Q43PrettyMiles);
                Q43Stops.setText("Stops Away: " + Q43StopCount);
            }
        });

// Add the request to the RequestQueue.
        queue.add(stringRequest);




    }



    private void getQ36(){

// ...

// Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="http://bustime.mta.info/api/siri/stop-monitoring.json?key=88059407-c3f9-4fb6-802c-c243ebe53cbb&OperatorRef=MTA&MonitoringRef=501908&LineRef=MTA NYCT_Q36";

// Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        //  textView.setText("Response is: "+ response);
                        try {
                            JSONObject x = new JSONObject(response);

                            JSONObject nearestBus = x.getJSONObject("Siri").getJSONObject("ServiceDelivery").getJSONArray("StopMonitoringDelivery").getJSONObject(0).getJSONArray("MonitoredStopVisit").getJSONObject(0).getJSONObject("MonitoredVehicleJourney").getJSONObject("MonitoredCall").getJSONObject("Extensions").getJSONObject("Distances");
                            Q36StopCount = Integer.parseInt(nearestBus.getString("StopsFromCall"));
                            Q36PrettyMiles = nearestBus.getString("PresentableDistance");

                            Q36Miles.setText(Q36PrettyMiles);
                            Q36Stops.setText("Stops Away: " + Q36StopCount);


                        } catch (JSONException e) {
                            e.printStackTrace();
                            Q36StopCount = 0;
                            Q36PrettyMiles = "NO BUSES EN-ROUTE";
                            Q36Miles.setText(Q36PrettyMiles);
                            Q36Stops.setText("Stops Away: " + Q36StopCount);
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Q36StopCount = 0;
                Q36PrettyMiles = "API FAILED";
                Q36Miles.setText(Q36PrettyMiles);
                Q36Stops.setText("Stops Away: " + Q36StopCount);
            }
        });

// Add the request to the RequestQueue.
        queue.add(stringRequest);




    }


    private void getQ1(){

// ...

// Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="http://bustime.mta.info/api/siri/stop-monitoring.json?key=88059407-c3f9-4fb6-802c-c243ebe53cbb&OperatorRef=MTA&MonitoringRef=500007&LineRef=MTA NYCT_Q1";

// Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        //  textView.setText("Response is: "+ response);
                        try {
                            JSONObject x = new JSONObject(response);

                            JSONObject nearestBus = x.getJSONObject("Siri").getJSONObject("ServiceDelivery").getJSONArray("StopMonitoringDelivery").getJSONObject(0).getJSONArray("MonitoredStopVisit").getJSONObject(0).getJSONObject("MonitoredVehicleJourney").getJSONObject("MonitoredCall").getJSONObject("Extensions").getJSONObject("Distances");
                            Q1StopCount = Integer.parseInt(nearestBus.getString("StopsFromCall"));
                            Q1PrettyMiles = nearestBus.getString("PresentableDistance");

                            Q1Miles.setText(Q1PrettyMiles);
                            Q1Stops.setText("Stops Away: " + Q1StopCount);
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Q1StopCount = 0;
                            Q1PrettyMiles = "NO BUSES EN-ROUTE";
                            Q1Miles.setText(Q1PrettyMiles);
                            Q1Stops.setText("Stops Away: " + Q1StopCount);
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Q1StopCount = 0;
                Q1PrettyMiles = "API FAILED";
                Q1Miles.setText(Q1PrettyMiles);
                Q1Stops.setText("Stops Away: " + Q1StopCount);
            }
        });

// Add the request to the RequestQueue.
        queue.add(stringRequest);




    }
}
